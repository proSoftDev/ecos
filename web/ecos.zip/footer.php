<div class="container">
	<div class="row">
		<div class="col-sm-12 col-md-3 footer-nav">
			<div class="logo">
				<img src="images/logo2.png" alt="logo">
			</div>
			<p class="mt-4"><span>© 2017</span></p><p class="break">ТОО «Компания ECOS»<p class="break"><span class="grey">Все права защищены</span></p></p>			
		</div>
		<div class="col-sm-12 col-md-3 footer-nav">
			<a href="about.php">О компании</a>
			<a href="production.php">Продукции</a>
			<a href="services.php">Услуги</a>
			<a href=".php">Безопасность и качество</a>
			<a href="news.php">Новости</a>
		</div>
		<div class="col-sm-12 col-md-3 footer-nav">
			<h4>Республика Казахстан, г.Алматы
				<p><span>Бостандыкский район, Жарокова 210А.</span></p>
			</h4>
			<p>Тел: <a href="tel: +7(727)356-33-56">+7 (727) 356-33-56</a></p>
			<p>Тел: <a href="tel: +7(727)356-05-19">+7 (727) 356-05-19</a></p>
			<p>Email: <a href="mailto:ecos@ecos.kz">ecos@ecos.kz</a></p>
		</div>
		<div class="col-sm-12 col-md-3 footer-nav">
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d726.8468693337454!2d76.90169707204218!3d43.222335097829514!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x388369fba985ead5%3A0x1bfda4abf61624d8!2z0YPQu9C40YbQsCDQltCw0YDQvtC60L7QstCwIDIxMEEsINCQ0LvQvNCw0YLRiyAwNTAwMDA!5e0!3m2!1sru!2skz!4v1568462790820!5m2!1sru!2skz" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
		</div>
	</div>
</div>