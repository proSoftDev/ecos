	<div class="container-fluid">
		<div id="partnersCarousel" class="carousel slide" data-ride="carousel" data-interval="8000">
			<div class="carousel-inner">
				<div class="carousel-item active">
					<div class="container">
							<div class="row">
								<div class="col-sm-12 col-md-4 separator">
									<img src="images/partner-logo_01.png">
									<h2 class="partners-name">АО “Тульский завод”</h2>
								  <a class="moreOfProductions" href="production.php">Продукции</a>
								</div>
								<div class="col-sm-12 col-md-4 separator">
									<img src="images/partner-logo_02.png">
									<h2 class="partners-name">ООО “Металликум”</h2>
								  <a class="moreOfProductions" href="production.php">Продукции</a>
								</div>
								<div class="col-sm-12 col-md-4 separator">
									<img src="images/partner-logo_03.png">
									<h2 class="partners-name">ООО “Стройцветмет”</h2>
								  <a class="moreOfProductions" href="production.php">Продукции</a>
								</div>
								<div class="col-sm-12 col-md-4 separator">
									<img src="images/partner-logo_04.png">
									<h2 class="partners-name">АО “Тульский завод”</h2>
								  <a class="moreOfProductions" href="production.php">Продукции</a>
								</div>
								<div class="col-sm-12 col-md-4 separator">
									<img src="images/partner-logo_05.png">
									<h2 class="partners-name">ООО “Металликум”</h2>
								  <a class="moreOfProductions" href="production.php">Продукции</a>
								</div>
								<div class="col-sm-12 col-md-4 separator">
									<img src="images/partner-logo_06.png">
									<h2 class="partners-name">ООО “Стройцветмет”</h2>
								  <a class="moreOfProductions" href="production.php">Продукции</a>
								</div>
						</div>
					</div>
				</div>
				<div class="carousel-item">
					<div class="container">
							<div class="row">
								<div class="col-sm-12 col-md-4 separator">
									<img src="images/partner-logo_01.png">
									<h2 class="partners-name">АО “Тульский завод”</h2>
								  <a class="moreOfProductions" href="production.php">Продукции</a>
								</div>
								<div class="col-sm-12 col-md-4 separator">
									<img src="images/partner-logo_02.png">
									<h2 class="partners-name">ООО “Металликум”</h2>
								  <a class="moreOfProductions" href="production.php">Продукции</a>
								</div>
								<div class="col-sm-12 col-md-4 separator">
									<img src="images/partner-logo_03.png">
									<h2 class="partners-name">ООО “Стройцветмет”</h2>
								  <a class="moreOfProductions" href="production.php">Продукции</a>
								</div>
								<div class="col-sm-12 col-md-4 separator">
									<img src="images/partner-logo_04.png">
									<h2 class="partners-name">АО “Тульский завод”</h2>
								  <a class="moreOfProductions" href="production.php">Продукции</a>
								</div>
								<div class="col-sm-12 col-md-4 separator">
									<img src="images/partner-logo_05.png">
									<h2 class="partners-name">ООО “Металликум”</h2>
								  <a class="moreOfProductions" href="production.php">Продукции</a>
								</div>
								<div class="col-sm-12 col-md-4 separator">
									<img src="images/partner-logo_06.png">
									<h2 class="partners-name">ООО “Стройцветмет”</h2>
								  <a class="moreOfProductions" href="production.php">Продукции</a>
								</div>
						</div>
					</div>
				</div>	
			</div>
			<div class="container">
				<div class="row">
					<div class="col-6 left-arrow">
						<div class="left-bg">
							<a class="" href="#partnersCarousel" role="button" data-slide="prev">
    							<span class="" aria-hidden="true"></span>
    							<span class="sr-only">Previous</span>
  							</a>
						</div>
					</div>
					<div class="col-6 right-arrow">
						<div class="right-bg">
							<a class="" href="#partnersCarousel" role="button" data-slide="next">
								<span class="" aria-hidden="true"></span>
							 	<span class="sr-only">Next</span>
							</a>
						</div>
					</div>
  				</div>
			</div>
		</div>
	</div>