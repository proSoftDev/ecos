	<div class="container-fluid">
		<div id="carouselExampleControls" class="carousel slide" data-ride="carousel" data-interval="4000">
			<div class="carousel-inner">
				<div class="carousel-item active">
					<div class="container">
							<div class="row">
								<div class="col-sm-12 col-md-4 separator">
									<img src="images/partner-logo_01.png">
									<p>АО “Тульский завод”</p>
								</div>
								<div class="col-sm-12 col-md-4 separator">
									<img src="images/partner-logo_02.png">
									<p>ООО “Металликум”</p>
								</div>
								<div class="col-sm-12 col-md-4 separator">
									<img src="images/partner-logo_03.png">
									<p>ООО “Стройцветмет”</p>
								</div>
								<div class="col-sm-12 col-md-4 separator">
									<img src="images/partner-logo_04.png">
									<p>АО “Тульский завод”</p>
								</div>
								<div class="col-sm-12 col-md-4 separator">
									<img src="images/partner-logo_05.png">
									<p>ООО “Металликум”</p>
								</div>
								<div class="col-sm-12 col-md-4 separator">
									<img src="images/partner-logo_06.png">
									<p>ООО “Стройцветмет”</p>
								</div>
						</div>
					</div>
				</div>
				<div class="carousel-item">
					<div class="container">
							<div class="row">
								<div class="col-sm-12 col-md-4 separator">
									<img src="images/partner-logo_01.png">
									<p>АО “Тульский завод”</p>
								</div>
								<div class="col-sm-12 col-md-4 separator">
									<img src="images/partner-logo_02.png">
									<p>ООО “Металликум”</p>
								</div>
								<div class="col-sm-12 col-md-4 separator">
									<img src="images/partner-logo_03.png">
									<p>ООО “Стройцветмет”</p>
								</div>
								<div class="col-sm-12 col-md-4 separator">
									<img src="images/partner-logo_04.png">
									<p>АО “Тульский завод”</p>
								</div>
								<div class="col-sm-12 col-md-4 separator">
									<img src="images/partner-logo_05.png">
									<p>ООО “Металликум”</p>
								</div>
								<div class="col-sm-12 col-md-4 separator">
									<img src="images/partner-logo_06.png">
									<p>ООО “Стройцветмет”</p>
								</div>
						</div>
					</div>
				</div>	
			</div>
			<div class="container">
				<div class="row">
					<div class="col-6 left-arrow">
						<div class="left-bg">
							<a class="" href="#carouselExampleControls" role="button" data-slide="prev">
    							<span class="" aria-hidden="true"></span>
    							<span class="sr-only">Previous</span>
  							</a>
						</div>
					</div>
					<div class="col-6 right-arrow">
						<div class="right-bg">
							<a class="" href="#carouselExampleControls" role="button" data-slide="next">
								<span class="" aria-hidden="true"></span>
							 	<span class="sr-only">Next</span>
							</a>
						</div>
					</div>
  				</div>
			</div>
		</div>
	</div>